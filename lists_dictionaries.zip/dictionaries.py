user = ["taha@sefactory.io", 88, True, "tahataha"]

username = user[0]
email = user[1]
age = user[2]
verified = user[3]


user = {
  "email": "taha@sefactory",
  "age":88,
  "name": "tahataha",
  "verified": True,
}

print("email" in user)

# Exercise: count the number of repetitions for each character in a word
word = "sessioni"
tracker = {

}


for char in word: # "a"
  # check if this is an available key inside the dictionary
  if char in tracker:
    tracker[char] += 1
  else:
    tracker[char] = 1

for key in tracker:
  print(key, "is repeated:", tracker[key], "times")
