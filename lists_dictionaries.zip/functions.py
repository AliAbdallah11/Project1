school = [ 55, 84, 95, 21, 61, 77, 71 ]
uni = [ 55, 74, 12, 79, 98 ]


def find_avg():
  sum = 0

  for grade in school:
    sum += grade

  avg = sum // len(school)

  print(f"Average is: {avg}")

find_avg()
