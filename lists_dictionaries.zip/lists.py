# Exercise 1:
# Given a list of grades (numbers) 0 - 100
# count the failing grades + find the average of the passing grades ONLY (70 - passing grade)
# grades = [71, 55, 84, 95, 21, 61, 77]
# failing = 0
# sum = 0

# First Approach ============
# for i in range(len(grades)):
#   if grades[i] < 70:
#     failing += 1
#   else:
#     sum += grades[i]
#     number += 1

# avg = sum / number

# Second Approach ============
# for i in range(len(grades)):
#   if grades[i] < 70:
#     failing += 1
#   else:
#     sum += grades[i]

# number = len(grades) - failing
# avg = sum / number

# Third Approach ============
# failing = []
# passing = []

# for grade in grades:
#   if grade < 70:
#     failing.append(grade)
#   else:
#     passing.append(grade)

# print(f"Failing grades: {len(failing)}")
# print(f"Average passing grades: {sum(passing)//len(passing)}")


# Exercise 2:
# Given a list of random numbers
# Find the second greatest number in the list

numbers = [ 55, 84, 95, 21, 61, 77, 71 ]
max = numbers[0] # 95
second = 0 # 84

# for i in range(1, len(numbers)):
#   if numbers[i] > max:
#     second = max
#     max = numbers[i]

# print(second)


print(numbers)
for i in range(len(numbers)):
  numbers[i] += 5

print(numbers)